﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2
{
    public abstract class driver
    {
        public abstract double area(double s);
        public abstract double volume(double s);

        public abstract double areaa(double l, double b, double h);
        public abstract double volum(double l, double b, double h);

        public abstract double areeaa(double r, double h);
        public abstract double volumee(double r, double h);

    }
}
