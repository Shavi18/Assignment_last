﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2
{
    public class cube : driver
    {
        public override double area(double s)
        {
            double arr = 6 * s * s;
            return arr;
        }

        public override double areaa(double l, double b, double h)
        {
            throw new NotImplementedException();
        }

        public override double areeaa(double r, double h)
        {
            throw new NotImplementedException();
        }

        public override double volum(double l, double b, double h)
        {
            throw new NotImplementedException();
        }

        public override double volume(double s)
        {
            double vol = s * s * s;
            return vol;
        }

        public override double volumee(double r, double h)
        {
            throw new NotImplementedException();
        }
    }
    


}
