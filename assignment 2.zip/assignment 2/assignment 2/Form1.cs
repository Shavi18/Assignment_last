﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        
        private void button3_Click(object sender, EventArgs e)
        {
            string nme = textBox1.Text;
            int hrs = int.Parse(textBox2.Text);
            double sly = double.Parse(textBox3.Text);
            employee accountant = new employee();
            if (nme.Any(char.IsDigit))
            {
                label4.Text = accountant.validator();
                label4.ForeColor = Color.Red;
            }
            else
            {
                double m = accountant.calsalary(hrs, sly);
                label4.Text = "The salary of " +nme+ " per day is " + m;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            double side = double.Parse(textBox9.Text);
            driver obj = new cube();
            double abc = obj.area(side);
            label17.Text = abc.ToString();

            double def = obj.volume(side);
            label18.Text = def.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double length = double.Parse(textBox4.Text);
            double breadth = double.Parse(textBox5.Text);
            double height = double.Parse(textBox6.Text);
            driver obj = new cuboid();

            double ab = obj.areaa(length, breadth, height);
            label19.Text = ab.ToString();

            double cd = obj.volum(length, breadth, height);
            label20.Text = cd.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double radius = double.Parse(textBox7.Text);
            double height = double.Parse(textBox8.Text);
            driver obj = new cylinder();
            double a = obj.areeaa(radius, height);
            label11.Text = a.ToString();

            double b = obj.volumee(radius, height);
            label13.Text = b.ToString();

        }
    }
}
