﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2
{
    public class cuboid : driver
    {
        public override double area(double s)
        {
            throw new NotImplementedException();
        }

        public override double areaa(double l,double b, double h )
        {
            double arr = 2*((l * b)+(b * h)+(h * l));
            return arr;
        }

        public override double areeaa(double r, double h)
        {
            throw new NotImplementedException();
        }

        public override double volum(double l,double b, double h)
        {
            double vol = l * b * h;
            return vol;
        }

        public override double volume(double s)
        {
            throw new NotImplementedException();
        }

        public override double volumee(double r, double h)
        {
            throw new NotImplementedException();
        }
    }
}
