﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2
{
    public class employee
    {
        double a;
        string b;

        public employee()
        {
            string name = "";
            int hours = 0;
            double salary = 0;
        }

        public string validator()
        {
            b = "name should contain only alphabets";
            return b;
        }
        public double calsalary(int hours,double salary)
        {
            a = hours * salary;
            return a;
        }
    }
          
}