﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2
{
    public class cylinder : driver
    {
        public override double area(double s)
        {
            throw new NotImplementedException();
        }

        public override double areaa(double l, double b, double h)
        {
            throw new NotImplementedException();
        }

        public override double areeaa(double r, double h)
        {
            double arr = (2 * 3.14 * r * h)+(2 * 3.14 * r * r);
            return arr;
        }

        public override double volum(double l, double b, double h)
        {
            throw new NotImplementedException();
        }

        public override double volume(double s)
        {
            throw new NotImplementedException();
        }

        public override double volumee(double r, double h)
        {
            double vol = 3.14 * r * r * h;
            return vol;
        }
    }
}
